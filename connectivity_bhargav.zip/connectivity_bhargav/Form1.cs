﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;


namespace connectivity_bhargav
{
    public partial class Form1 : Form
    {

        string s = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=\\Mac\Home\Downloads\connectivity_bhargav\Database1.mdf;Integrated Security=True";
        SqlConnection con;
        DataSet ds;
        SqlDataAdapter da;
        SqlCommand cmd;
        string g;


        void getcon()
        {
            con = new SqlConnection(s);
            con.Open();

        }

        void gender()
        {
            if(rbtnmale.Checked)
            {
                g = "Male";
            }
            else
            {
                g = "Female";
            }
        }

        void filldata()
        {
            getcon();
            da = new SqlDataAdapter("select*from emp where id=" + Program.id + "", con);
            ds = new DataSet();
            da.Fill(ds);
            txtnm.Text = ds.Tables[0].Rows[0][1].ToString();
            if(rbtnmale.Text==ds.Tables[0].Rows[0][2].ToString())
            {
                rbtnmale.Checked = true;
            }
            else
            {
                rbtnfmale.Checked = true;
            }
            cmbcity.SelectedItem = ds.Tables[0].Rows[0][3].ToString();
            txtmail.Text = ds.Tables[0].Rows[0][4].ToString();
            txtno.Text = ds.Tables[0].Rows[0][5].ToString();
        }
        void col()
        {
            dataGridView1.AutoGenerateColumns = false;
            DataGridViewButtonColumn edit = new DataGridViewButtonColumn();
            edit.FlatStyle = FlatStyle.Popup;
            edit.HeaderText = "Edit";
            edit.Name = "Edit";
            edit.UseColumnTextForButtonValue = true;
            edit.Text = "Edit";
            edit.Width = 60;
            dataGridView1.Columns.Add(edit);


            dataGridView1.AutoGenerateColumns = false;
            DataGridViewButtonColumn delete = new DataGridViewButtonColumn();
            delete.FlatStyle = FlatStyle.Popup;
            delete.HeaderText = "Delete";
            delete.Name = "Delete";
            delete.UseColumnTextForButtonValue = true;
            delete.Text = "Delete";
            delete.Width = 60;
            dataGridView1.Columns.Add(delete);
        }

        void fillgrid()
        {
            getcon();
            da = new SqlDataAdapter("select * from emp",con);
            ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }


        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            gender();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            getcon();
            fillgrid();
            col();
            cmbcity.Items.Add("Rajkot");
            cmbcity.Items.Add("Jaipur");
            cmbcity.Items.Add("Ahemdabad");
            cmbcity.Items.Add("junagadh");


        }

        private void button1_Click(object sender, EventArgs e)
        {
            getcon();
                if(button1.Text=="Submit")
            {
                cmd = new SqlCommand("insert into emp(name,gender,city,email,mobile) values('" + txtnm.Text + "','" + g + "','" + cmbcity.SelectedItem + "','" + txtmail.Text + "','" + txtno.Text + "')", con);
                cmd.ExecuteNonQuery();
                fillgrid();
            }
                else if(button1.Text=="Update")
            {
                SqlCommand cmd = new SqlCommand("update emp set name='" + txtnm.Text + "',gender='" + g + "',city='" + cmbcity.SelectedItem + "',email='" + txtmail.Text + "',mobile='" + txtno.Text + "'where id='"+Program.id+"'", con);
                cmd.ExecuteNonQuery();
                fillgrid();
            }
        }

        private void rbtnmale_CheckedChanged(object sender, EventArgs e)
        {
            gender();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.ColumnIndex==6)
            {
                button1.Text = "Update";
                Program.id = Convert.ToInt16(dataGridView1.Rows[e.RowIndex].Cells["id"].FormattedValue);
                filldata();
                
            }
            else if(e.ColumnIndex==7)
            {
                getcon();
                Program.id = Convert.ToInt16(dataGridView1.Rows[e.RowIndex].Cells["id"].FormattedValue);

                SqlCommand cmd = new SqlCommand("delete from emp where id="+Program.id+"", con);
                cmd.ExecuteNonQuery();
                fillgrid();
            }

        }
    }
}
